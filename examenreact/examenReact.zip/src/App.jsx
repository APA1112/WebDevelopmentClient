import Categorias from "./assets/components/Categoria";
import "./App.css";

function App() {
  const [categoriasBuscar, setCategoriasBuscar] = ([])

  const categorias = fetch("https://fakestoreapi.com/products/categories").then(response => response.json()).then(data => console.log(data));

  fetch(`https://fakestoreapi.com/products/category/electronics`).then(response => response.json()).then(data => console.log(data));

  return (
    <>
    <main className="main-wrapper">
      <header className="page-header">
        <h1 className="page-title">Tienda de Prueba Ajax</h1>
      </header>
      <div className="page-wrapper">
        <aside className="aside-wrapper">
          <div className="aside-section">
          <Categorias categorias={categorias}/>
          </div>
        </aside>
        <div className="content-wrapper">
          <h3 className="section-title">Artículos</h3>
          <div className="grid-container" id="grid-container">
          </div>
        </div>
      </div>
      </main>
    </>
  );
}

export default App;
