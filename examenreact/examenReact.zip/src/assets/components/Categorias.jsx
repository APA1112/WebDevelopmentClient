import Categoria from "./Categoria";

function Categorias(props){
    const categorias = props.categorias.map((categoria)=><Categoria categoria={categoria}/>)

    return (
        <>
        <h3 className="section-title">Filtros</h3>
        <div className="section-content">
            {categorias}
        </div>
        </>
    )
}

export default Categorias