function Categoria(props) {

  return (
    <div className="section-content">
      <div className="item">
        <span className="item-content">{props.categoria}</span>
        <i className="fa fa-close delete-filter js-delete-filter"></i>
      </div>
    </div>
  );
}

export default Categoria;
